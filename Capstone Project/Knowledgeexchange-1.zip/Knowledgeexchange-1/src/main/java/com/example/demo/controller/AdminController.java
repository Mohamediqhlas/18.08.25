package com.example.demo.controller;

import com.example.demo.entity.Doubt;
import com.example.demo.entity.User;
import com.example.demo.repository.DoubtRepository;
import com.example.demo.repository.ReplyRepository;
import com.example.demo.repository.RoleRepository;
import com.example.demo.repository.UserRepository;
import org.springframework.data.domain.Sort;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Controller
@RequestMapping("/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    private final UserRepository userRepo;
    private final DoubtRepository doubtRepo;
    private final ReplyRepository replyRepo;
    private final RoleRepository roleRepo;
    private final PasswordEncoder passwordEncoder;

    public AdminController(UserRepository userRepo, DoubtRepository doubtRepo, 
                          ReplyRepository replyRepo, RoleRepository roleRepo,
                          PasswordEncoder passwordEncoder) {
        this.userRepo = userRepo;
        this.doubtRepo = doubtRepo;
        this.replyRepo = replyRepo;
        this.roleRepo = roleRepo;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping("/dashboard")
    @Transactional(readOnly = true)
    public String adminDashboard(Model model) {
        long totalUsers = userRepo.count();
        long totalDoubts = doubtRepo.count();
        long unansweredDoubts = doubtRepo.countUnansweredDoubts();
        long totalReplies = replyRepo.count();
        
        List<Doubt> recentDoubts = new ArrayList<>();
        List<Doubt> unansweredList = new ArrayList<>();
        
        try {
            recentDoubts = doubtRepo.findAllWithReplies();
            unansweredList = recentDoubts.stream()
                .filter(d -> d.getReplies() == null || d.getReplies().isEmpty())
                .limit(10)
                .toList();
        } catch (Exception e) {
            // Fallback to standard findAll
            recentDoubts = doubtRepo.findAll(Sort.by(Sort.Direction.DESC, "createdAt"));
            unansweredList = recentDoubts.stream()
                .filter(d -> d.getReplies() == null || d.getReplies().isEmpty())
                .limit(10)
                .toList();
        }
        
        List<User> allUsers = userRepo.findAll(Sort.by(Sort.Direction.DESC, "createdAt"));
        
        model.addAttribute("totalUsers", totalUsers);
        model.addAttribute("totalDoubts", totalDoubts);
        model.addAttribute("unansweredDoubts", unansweredDoubts);
        model.addAttribute("totalReplies", totalReplies);
        model.addAttribute("recentDoubts", recentDoubts);
        model.addAttribute("unansweredList", unansweredList);
        model.addAttribute("allUsers", allUsers);
        return "admin_dashboard";
    }

    @GetMapping("/users")
    @PreAuthorize("hasRole('ADMIN')")
    @Transactional(readOnly = true)
    public String userList(Model model) {
        List<User> users = userRepo.findAll(Sort.by(Sort.Direction.DESC, "createdAt"));
        model.addAttribute("users", users);
        return "admin_users";
    }

    @PostMapping("/users/{id}/toggle-role")
    @PreAuthorize("hasRole('ADMIN')")
    @Transactional
    public String toggleUserRole(@PathVariable Long id) {
        User user = userRepo.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("User not found"));
        
        var adminRole = roleRepo.findByName("ROLE_ADMIN")
            .orElseGet(() -> {
                var r = new com.example.demo.entity.Role();
                r.setName("ROLE_ADMIN");
                return roleRepo.save(r);
            });
        
        var userRole = roleRepo.findByName("ROLE_USER")
            .orElseGet(() -> {
                var r = new com.example.demo.entity.Role();
                r.setName("ROLE_USER");
                return roleRepo.save(r);
            });
        
        if (user.getRoles().stream().anyMatch(r -> r.getName().equals("ROLE_ADMIN"))) {
            user.setRoles(Set.of(userRole));
        } else {
            user.setRoles(Set.of(adminRole));
        }
        userRepo.save(user);
        return "redirect:/admin/users";
    }

    @PostMapping("/doubts/{id}/delete")
    @PreAuthorize("hasRole('ADMIN')")
    @Transactional
    public String deleteDoubt(@PathVariable Long id) {
        doubtRepo.deleteById(id);
        return "redirect:/admin/dashboard";
    }
}
