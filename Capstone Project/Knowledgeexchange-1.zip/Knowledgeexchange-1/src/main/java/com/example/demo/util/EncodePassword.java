package com.example.demo.util;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class EncodePassword {
    public static String hash(String raw) {
        return new BCryptPasswordEncoder().encode(raw);
    }
}
