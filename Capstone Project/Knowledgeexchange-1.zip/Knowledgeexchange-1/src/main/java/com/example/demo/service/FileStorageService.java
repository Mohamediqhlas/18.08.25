package com.example.demo.service;

import com.example.demo.entity.Attachment;
import com.example.demo.entity.Doubt;
import com.example.demo.repository.AttachmentRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

@Service
public class FileStorageService {

    private final AttachmentRepository attachmentRepo;

    // absolute uploads path under project root
    private final String uploadDir = System.getProperty("user.dir") + File.separator + "uploads";

    public FileStorageService(AttachmentRepository attachmentRepo) {
        this.attachmentRepo = attachmentRepo;
    }

    public void storeAll(Doubt doubt, MultipartFile[] files) {
        if (files == null || files.length == 0) return;

        File base = new File(uploadDir);
        if (!base.exists() && !base.mkdirs()) {
            throw new RuntimeException("Could not create upload directory: " + base.getAbsolutePath());
        }

        for (MultipartFile mf : files) {
            if (mf == null || mf.isEmpty()) continue;

            String original = mf.getOriginalFilename() == null ? "file" : mf.getOriginalFilename();
            String safeOriginal = original.replaceAll("[\\\\/:*?\"<>|]", "_");
            String filename = System.currentTimeMillis() + "_" + safeOriginal;
            File dest = new File(base, filename);

            File parent = dest.getParentFile();
            if (parent != null && !parent.exists() && !parent.mkdirs()) {
                throw new RuntimeException("Could not create parent directories for file: " + dest.getAbsolutePath());
            }

            try (InputStream in = mf.getInputStream()) {
                Files.copy(in, dest.toPath(), StandardCopyOption.REPLACE_EXISTING);

                Attachment att = new Attachment();
                att.setFilename(filename);                 // maps to DB 'filename'
                att.setOriginalName(safeOriginal);         // maps to DB 'original_name'
                att.setStoragePath(dest.getAbsolutePath()); // maps to DB 'storage_path'
                att.setContentType(mf.getContentType());
                att.setSize(mf.getSize());
                att.setDoubt(doubt);

                attachmentRepo.save(att);
            } catch (IOException e) {
                throw new RuntimeException("File save failed for " + original, e);
            }
        }
    }
}
