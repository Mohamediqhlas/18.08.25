package com.example.demo.service;

import com.example.demo.entity.Doubt;
import com.example.demo.entity.Reply;
import com.example.demo.entity.User;
import com.example.demo.repository.DoubtRepository;
import com.example.demo.repository.ReplyRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.util.Date;
import java.util.List;

@Service
public class DoubtService {

    private final DoubtRepository doubtRepo;
    private final ReplyRepository replyRepo;
    private final FileStorageService fileStorageService;

    public DoubtService(DoubtRepository doubtRepo, ReplyRepository replyRepo, FileStorageService fileStorageService) {
        this.doubtRepo = doubtRepo;
        this.replyRepo = replyRepo;
        this.fileStorageService = fileStorageService;
    }

    @Transactional(readOnly = true)
    public List<Doubt> listAll() {
        return doubtRepo.findAll();
    }

    @Transactional(readOnly = true)
    public Doubt get(Long id) {
        return doubtRepo.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Doubt not found"));
    }

    @Transactional
    public Doubt create(User user, String title, String description, MultipartFile[] files) {
        Doubt doubt = new Doubt();
        doubt.setCreatedBy(user);
        doubt.setTitle(title);
        doubt.setDescription(description);
        doubt.setCreatedAt(new Date());
        doubt = doubtRepo.save(doubt);

        if (files != null && files.length > 0) {
            fileStorageService.storeAll(doubt, files);
        }
        return doubt;
    }

    @Transactional
    public void addReply(Long doubtId, User user, String content) {
        Doubt doubt = get(doubtId);
        Reply reply = new Reply();
        reply.setDoubt(doubt);
        reply.setUser(user);
        reply.setContent(content);
        reply.setCreatedAt(new Date());
        replyRepo.save(reply);
    }
}
