package com.example.demo.entity;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "replies")
public class Reply {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne @JoinColumn(name = "doubt_id")
    private Doubt doubt;

    @ManyToOne @JoinColumn(name = "user_id")
    private User user;

    @Column(length = 5000)
    private String content;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_at")
    private Date createdAt = new Date();

    // getters and setters
    public Long getId() { return id; } public void setId(Long id) { this.id = id; }
    public Doubt getDoubt() { return doubt; } public void setDoubt(Doubt doubt) { this.doubt = doubt; }
    public User getUser() { return user; } public void setUser(User user) { this.user = user; }
    public String getContent() { return content; } public void setContent(String content) { this.content = content; }
    public Date getCreatedAt() { return createdAt; } public void setCreatedAt(Date createdAt) { this.createdAt = createdAt; }
}
