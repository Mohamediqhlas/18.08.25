package com.example.demo.repository;

import com.example.demo.entity.Doubt;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface DoubtRepository extends JpaRepository<Doubt, Long> {
    @Query("SELECT COUNT(d) FROM Doubt d LEFT JOIN d.replies r WHERE r IS NULL")
    long countUnansweredDoubts();
    
    @Query("SELECT DISTINCT d FROM Doubt d LEFT JOIN FETCH d.replies LEFT JOIN FETCH d.createdBy LEFT JOIN FETCH d.attachments ORDER BY d.createdAt DESC")
    List<Doubt> findAllWithReplies();
    
    @Query("SELECT DISTINCT d FROM Doubt d LEFT JOIN FETCH d.replies LEFT JOIN FETCH d.createdBy LEFT JOIN FETCH d.attachments ORDER BY d.createdAt DESC")
    List<Doubt> findAllFetched();
}
