package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Knowledgeexchange1Application {
    public static void main(String[] args) {
        SpringApplication.run(Knowledgeexchange1Application.class, args);
    }
}
