package com.example.demo.controller;

import com.example.demo.entity.Attachment;
import com.example.demo.repository.AttachmentRepository;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.io.File;

@Controller
public class FileController {

    private final AttachmentRepository attachmentRepo;

    public FileController(AttachmentRepository attachmentRepo) {
        this.attachmentRepo = attachmentRepo;
    }

    @GetMapping("/files/{id}")
    public ResponseEntity<FileSystemResource> download(@PathVariable Long id) {
        // 1) Find attachment record or return 404
        Attachment f = attachmentRepo.findById(id)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "File not found"));

        // 2) Use the entity getter that maps to DB column 'storage_path'
        String path = f.getStoragePath();
        if (path == null || path.isBlank()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "File path not available");
        }

        // 3) Check file exists on disk
        File file = new File(path);
        if (!file.exists() || !file.isFile()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "File not found on disk");
        }

        // 4) Prepare resource and content type safely
        FileSystemResource res = new FileSystemResource(file);
        MediaType type;
        try {
            type = (f.getContentType() != null && !f.getContentType().isBlank())
                    ? MediaType.parseMediaType(f.getContentType())
                    : MediaType.APPLICATION_OCTET_STREAM;
        } catch (Exception ex) {
            type = MediaType.APPLICATION_OCTET_STREAM;
        }

        // 5) Choose download filename (originalName preferred)
        String downloadName = (f.getOriginalName() != null && !f.getOriginalName().isBlank())
                ? f.getOriginalName()
                : file.getName();

        return ResponseEntity.ok()
                .contentType(type)
                .contentLength(file.length())
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + downloadName + "\"")
                .body(res);
    }
}
