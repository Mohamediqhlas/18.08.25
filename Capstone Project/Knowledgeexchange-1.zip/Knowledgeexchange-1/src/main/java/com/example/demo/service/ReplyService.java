package com.example.demo.service;

import com.example.demo.entity.Reply;
import com.example.demo.repository.ReplyRepository;
import org.springframework.stereotype.Service;

@Service
public class ReplyService {
    private final ReplyRepository replyRepo;
    public ReplyService(ReplyRepository replyRepo) { this.replyRepo = replyRepo; }
    public Reply save(Reply reply) { return replyRepo.save(reply); }
}
