package com.example.demo.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "attachments")
public class Attachment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // map to DB column 'filename'
    @Column(name = "filename", nullable = false)
    private String filename;

    // map to DB column 'original_name'
    @Column(name = "original_name")
    private String originalName;

    // map to DB column 'storage_path'
    @Column(name = "storage_path", nullable = false)
    private String storagePath;

    @Column(name = "content_type")
    private String contentType;

    @Column(name = "size")
    private long size;

    @ManyToOne
    @JoinColumn(name = "doubt_id")
    private Doubt doubt;

    // getters and setters
    public Long getId() { return id; } public void setId(Long id) { this.id = id; }

    public String getFilename() { return filename; } public void setFilename(String filename) { this.filename = filename; }

    public String getOriginalName() { return originalName; } public void setOriginalName(String originalName) { this.originalName = originalName; }

    public String getStoragePath() { return storagePath; } public void setStoragePath(String storagePath) { this.storagePath = storagePath; }

    public String getContentType() { return contentType; } public void setContentType(String contentType) { this.contentType = contentType; }

    public long getSize() { return size; } public void setSize(long size) { this.size = size; }

    public Doubt getDoubt() { return doubt; } public void setDoubt(Doubt doubt) { this.doubt = doubt; }
}
