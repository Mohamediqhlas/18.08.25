package com.example.demo.controller;

import com.example.demo.entity.Doubt;
import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.DoubtService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Controller
public class DoubtController {

    private final DoubtService doubtService;
    private final UserRepository userRepo;

    public DoubtController(DoubtService doubtService, UserRepository userRepo) {
        this.doubtService = doubtService;
        this.userRepo = userRepo;
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        List<Doubt> doubts = doubtService.listAll();
        model.addAttribute("doubts", doubts);
        return "dashboard";
    }

    @GetMapping("/doubts")
    public String listDoubts(Model model) {
        List<Doubt> doubts = doubtService.listAll();
        model.addAttribute("doubts", doubts);
        return "doubts";
    }

    @GetMapping("/doubts/new")
    public String newDoubtForm() {
        return "doubt_form";
    }

    @GetMapping("/doubts/{id}")
    public String viewDoubt(@PathVariable Long id, Model model) {
        Doubt doubt = doubtService.get(id);
        model.addAttribute("doubt", doubt);
        return "doubt_detail";
    }

    @PostMapping("/doubts")
    public String addDoubt(@AuthenticationPrincipal UserDetails principal,
                           @RequestParam String title,
                           @RequestParam String description,
                           @RequestParam(value = "files", required = false) MultipartFile[] files) {

        User currentUser = userRepo.findByEmail(principal.getUsername())
            .orElseThrow(() -> new IllegalArgumentException("Logged-in user not found"));

        doubtService.create(currentUser, title, description, files);
        return "redirect:/dashboard";
    }

    @PostMapping("/doubts/{id}/reply")
    public String addReply(@AuthenticationPrincipal UserDetails principal,
                           @PathVariable Long id,
                           @RequestParam String content) {

        User currentUser = userRepo.findByEmail(principal.getUsername())
            .orElseThrow(() -> new IllegalArgumentException("Logged-in user not found"));

        doubtService.addReply(id, currentUser, content);
        return "redirect:/doubts/" + id;
    }
}