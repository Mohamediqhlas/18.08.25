// main.js
document.addEventListener("DOMContentLoaded", () => {
  console.log("Main frontend script loaded.");

  // 1) Prevent accidental double submits by disabling the submit button once clicked
  document.querySelectorAll("form").forEach(form => {
    form.addEventListener("submit", (e) => {
      const btn = form.querySelector('button[type="submit"], input[type="submit"]');
      if (btn) {
        // disable after a tiny delay so form still submits normally
        setTimeout(() => { btn.disabled = true; btn.classList.add('disabled'); }, 10);
      }
      console.log("Form submitted:", form.action, "method:", form.method);
    });
  });

  // 2) Confirm delete helper used by delete forms
  window.confirmDelete = function() {
    return confirm('Are you sure you want to delete this item? This action cannot be undone.');
  };

  // 3) File input preview: show selected filenames in a sibling .file-names element
  document.addEventListener('change', function (e) {
    if (!e.target) return;
    const el = e.target;
    if (el.matches('input[type="file"][name="files"]')) {
      const names = Array.from(el.files || []).map(f => f.name).join(', ');
      let info = el.parentElement.querySelector('.file-names');
      if (!info) {
        info = document.createElement('div');
        info.className = 'form-text file-names';
        el.parentElement.appendChild(info);
      }
      info.textContent = names ? 'Selected: ' + names : '';
    }
  });

  // 4) Small utility: safe element query
  window.$ = selector => document.querySelector(selector);

  // 5) Optional: show a small toast for success messages if an element exists
  const toastEl = document.getElementById('flash-message');
  if (toastEl && toastEl.textContent.trim()) {
    // simple fade out after 4 seconds
    setTimeout(() => { toastEl.style.transition = 'opacity 600ms'; toastEl.style.opacity = '0'; }, 4000);
  }
});
